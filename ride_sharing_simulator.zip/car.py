# car.py

class Car:
    """Represents a single vehicle in the ride-sharing simulation."""

    def __init__(self, car_id, initial_location):
        self.id = car_id
        self.location = initial_location
        self.status = "available"
        self.destination = None

    def __str__(self):
        return f"Car {self.id} at {self.location} - Status: {self.status}"
