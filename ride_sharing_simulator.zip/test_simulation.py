# test_simulation.py

from car import Car
from rider import Rider
from simulation import Simulation

# Create sample Car and Rider
car1 = Car("CAR001", (5, 10))
rider1 = Rider("RIDER_A", (2, 3), (8, 9))

# Create a Simulation instance and add the car and rider
sim = Simulation()
sim.cars[car1.id] = car1
sim.riders[rider1.id] = rider1

# Display the created instances
print(car1)
print(rider1)
print(sim)
