# simulation.py

class Simulation:
    """Controls the simulation environment. Stores all active cars and riders."""

    def __init__(self):
        self.cars = {}
        self.riders = {}

    def __str__(self):
        return (f"Simulation with {len(self.cars)} cars and "
                f"{len(self.riders)} riders.")
